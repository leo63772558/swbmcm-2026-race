Problem B source and evidence files.
Run python src/verify_handoff.py --reproduce-zip <path-to-this-zip> from the extracted directory.
Requires Python, pypdf, ReportLab, Pillow, Poppler pdftoppm, and Windows Times New Roman fonts.
B_P2_fairness.csv records the shared screening comparison. B_P4_cross.csv and B_P4_cross_timelines.json contain the crossed scenarios and event traces. B_P4_replay.csv contains cache and reset sensitivity checks.
